import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class display extends HttpServlet {

  public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {

    res.setContentType("text/html");
    PrintWriter out = res.getWriter();
    HttpSession session = req.getSession(true);
    out.println("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'/>");
    out.println("<html xmlns='http://www.w3.org/1999/xhtml'>");
    out.println("<head>");
    out.println("<title>Shop Online</title>");
    out.println("<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />");
    out.println("<link href='style/style.css' rel='stylesheet' type='text/css' />");
    out.println("<!--[if IE]>");
    out.println("<link href='style/style-ie.css' rel='stylesheet' type='text/css' />");
    out.println("<![endif]-->");
    out.println("</head>");
    out.println("<body>");
    out.println("<center>");
     out.println(" <div class='wrapper'>");
        out.println("<div class='logo'> Shop<strong>Online</strong></div>");
        out.println("<div class='menu'>");
          out.println("<ul class='solidblockmenu'>");
            out.println("<li><a href='#'>Home</a></li>");
            out.println("<li><a href='#'>Support</a></li>");
            out.println("<li><a href='#'>My Account</a></li>");
            out.println("<li><a href='#'>Reviews</a></li>");
            out.println("<li><a href='#'>Hot Deals</a></li>");
            out.println("<li><a href='#'>contact</a></li>");
          out.println("</ul>");
          out.println("<div class='clear'></div>");
        out.println("</div>");
     
       
      out.println("<div class='search'>");
        out.println("<div class='search-text'> Search the world of shopping!&nbsp;");
   	 out.println("<input type='text' size='40' />");
         out.println(" &nbsp;&nbsp;</div>");
        out.println("<div style='float:rith; margin-left:5px; margin-top:10px;'>");
          out.println("<input type='image' src='images/search.jpg' />");
        out.println("</div>");
      out.println("<div class='hot-search'>");
        out.println("<div class='hot-search-text'> Hot Searches: Apple iPod Nano, Hugo Boss Clothing, HD DVD Player, DSLR Camera, Toshiba 32&quot; LCD TV, Unsecured Loans, Excersise Machines..</div>");
      out.println("</div>");
      out.println("</div>");
      out.println("<div class='body-wrapper'>");
        out.println("<div class='body-right'>");
          out.println("<div class='body-right-box1'>");
            out.println("<div class='right-topic-title'> Favourite Items</div>");
            out.println("<br />");
            out.println("<div style='width:170px;padding-left:10px;'> <img src='images/mobile.jpg' style='float:left; margin-right: 0px;' alt='' />");
              out.println("<div style='width:140px; text-align:right; padding-left:3px;'>");
                out.println("<div class='product-title'> Nokia 8800 Arte</div>");
                out.println("<div class='product-price'> prices &nbsp;from &nbsp;&pound;749.99</div>");
                out.println("<div class='product-compare'> <u>Compare..</u>&nbsp;<img src='images/proceed.jpg' style='padding-top: 3px;' alt='' /></div>");
              out.println("</div>");
            out.println("</div>");
            out.println("<br />");
            out.println("<div style='width:170px;padding-left:10px;padding-top:3px;'> <img src='images/mobile.jpg' style='float:left; margin-right: 0px;' alt='' />");
              out.println("<div style='width:140px; text-align:right; padding-left:3px;'>");
                out.println("<div class='product-title'> Nokia 8800 Arte</div>");
                out.println("<div class='product-price'> prices &nbsp;from &nbsp;&pound;749.99</div>");
                out.println("<div class='product-compare'> <u>Compare..</u>&nbsp;<img src='images/proceed.jpg' style='padding-top: 3px;' alt='' /></div>");
              out.println("</div>");
            out.println("</div>");
            out.println("<br />");
            out.println("<div style='width:170px;padding-left:10px;padding-top:1px;'> <img src='images/mobile.jpg' style='float:left; margin-right: 0px;' alt='' />");
              out.println("<div style='width:140px; text-align:right; padding-left:3px;'>");
                out.println("<div class='product-title'> Nokia 8800 Arte</div>");
                out.println("<div class='product-price'> prices &nbsp;from &nbsp;&pound;749.99</div>");
                out.println("<div class='product-compare'> <u>Compare..</u>&nbsp;<img src='images/proceed.jpg' style='padding-top: 3px;' alt='' /></div>");
              out.println("</div>");
            out.println("</div>");
            out.println("<br />");
            out.println("<div style='width:170px;padding-left:10px;padding-top:2px;'> <img src='images/mobile.jpg' style='float:left; margin-right: 0px;' alt='' />");
              out.println("<div style='width:140px; text-align:right; padding-left:3px;'>");
               out.println("<div class='product-title'> Nokia 8800 Arte</div>");
                out.println("<div class='product-price'> prices &nbsp;from &nbsp;&pound;749.99</div>");
                out.println("<div class='product-compare'> <u>Compare..</u>&nbsp;<img src='images/proceed.jpg' style='padding-top: 3px;' alt='' /></div>");
             out.println("</div>");
           out.println("</div>");
            out.println("<br />");
            out.println("<div style='width:170px;padding-left:10px;padding-top:2px;'> <img src='images/mobile.jpg' style='float:left; margin-right: 0px;' alt='' />");
              out.println("<div style='width:140px; text-align:right; padding-left:3px;'>");
                out.println("<div class='product-title'> Nokia 8800 Arte</div>");
                out.println("<div class='product-price'> prices &nbsp;from &nbsp;&pound;749.99</div>");
                out.println("<div class='product-compare'> <u>Compare..</u>&nbsp;<img src='images/proceed.jpg' style='padding-top: 3px;' alt='' /></div>");
              out.println("</div>");
            out.println("</div>");
          out.println("</div>");
          out.println("<div class='separator'> &nbsp;</div>");
          out.println("<div class='body-right-ad1'> &nbsp;</div>");
          out.println("<div class='separator'> &nbsp;</div>");
   	   out.println("<!--end of banner-->");
   	   out.println("<div id='banner'>...</div>");
   	  	   out.println("<form name='frml'action='display'>");
   	   out.println("<input type='submit'value='Display users'/>");
        	    out.println("</form>");
   	             out.print("<table><tr><td>");
	out.println("Welcome " + (String) session.getAttribute("userName") + "!");
	out.println("</td></tr>");
	out.println("<tr><td>");
    out.print("<font color=green>First Name\t\t Last Name ");
    out.println("\t\t Mobile\n\n</font>");
	out.print("</td></tr>");
	 
    Connection con = null;
    
    try {
	  	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
		//make a connection
		con=DriverManager.getConnection("jdbc:ucanaccess://C:/apache-tomcat/webapps/shop-online/WEB-INF/database/Ab sta.accdb");
		System.out.println("Connection Successful");
		//creating object of statement
		Statement stat=con.createStatement();
		ResultSet rs = stat.executeQuery("select * from customer");
        
        	//displaying records
	      while(rs.next()) {
	      	out.print("<tr><td>");
	      	out.print(rs.getObject(3).toString());
	        out.print("\t");
	        out.print(rs.getObject(4).toString());
	        out.print("\t\t");
	        out.print(rs.getObject(5).toString());
	        out.print("\n");
	        out.print("</td></tr>");
	      }
	      out.println("table/");
	      out.println("<div class='divider1'> &nbsp;</div>");
	      out.println("<div class='body-middle'>");
	        out.println("<div class='body-middle-box1'>");
	          out.println("<div class='lcd-title'> New Year Sale!<br />");
	            out.println("Great HDTV Deals! <br />");
	            out.println("<br />");
	            out.println("<img src='images/findout.jpg' alt='' /></div>");
	        out.println("</div>");
	        out.println("<div class='separator-middle'> &nbsp;</div>");
	        out.println("<div class='body-middle-box2'>");
	          out.println("<div class='sale-title'> New Year Sale!</div>");
	          out.println("<div class='sale-desc'> Lorem ipsum dolor sit amet, consectetdipisicing elit, sed do eiusmod tempor incididabore et dolore magna aliqua. Ut enim ad mieniauis nostrud exercitation ullamco laboris nisiliquip ex ea. Lorem ipsum dolor sit amet, consecur adipisicing elit, sed do eiusmod tempcidi <br />");
	            out.println("<br />");
	            out.println("<img src='images/findout.jpg' alt='' /></div>");
	        out.println("</div>");
	        out.println("<div class='separator-middle'> &nbsp;</div>");
	        out.println("<div class='body-middle-box3'>");
	          out.println("<div class='gallery-name' style='margin-left:15px;padding-top:7px;'> New Stuff&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Top Sellers&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hot Deals</div>");
	          out.println("<div style='clear:both;'>");
	            out.println("<div class='gallery-product3'> <img src='images/ipod.jpg' alt='' />");
	              out.println("<div class='gallery-name'>iPod Classic!</div>");
	              out.println("<div class='gallery-price'>From &pound;129.99</div>");
	              out.println("<img src='images/goshop.jpg' alt='' /></div>");
	            out.println("<div class='gallery-product2'> <img src='images/ipod.jpg' alt='' />");
	              out.println("<div class='gallery-name'>iPod Classic!</div>");
	              out.println("<div class='gallery-price'>From &pound;129.99</div>");
	              out.println("<img src='images/goshop.jpg' /></div>");
	            out.println("<div class='gallery-product1'> <img src='images/ipod.jpg' alt='' />");
	              out.println("<div class='gallery-name'>iPod Classic!</div>");
	              out.println("<div class='gallery-price'>From &pound;129.99</div>");
	              out.println("<img src='images/goshop.jpg' alt='' /></div>");
	          out.println("</div>");
	        out.println("</div>");
	      out.println("</div>");
	      out.println("<div class='divider2'> &nbsp;</div>");
	      out.println("<div class='body-left'>");
	        out.println("<div class='left-main-title'> Shopping Categories</div>");
	        out.println("<div class='left-topic-title'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:25px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:28px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:30px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:30px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:30px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	        out.println("<div class='left-topic-title' style='padding-top:30px;'> Books, DVD&#8217;s &amp; Music</div>");
	        out.println("<div class='left-topic-desc'> CD&#8217;s, Magazine Subscriptions, 300: The Movie, &amp; more..</div>");
	      out.println("</div>");
	    out.println("</div>");
	    out.println("<div class='separator-main'> &nbsp;</div>");
	    out.println("<div class='footer'>");
	      out.println("<div class='footer-text' style='padding-top:10px;margin-left:20px;'> <a href='#' class='nav1'>Home</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>Categories</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>User Guide</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>Reviews</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>Hot Deals</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>FAQ&#8217;s</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>Contact</a>&nbsp;&nbsp;<span style='color:#dbdbdb'>|</span>&nbsp;&nbsp;<a href='#' class='nav1'>Privacy Policy</a></div>");
	      out.println("<div class='footer-text' style='padding-top:20px;margin-left:20px;'> Copyright &copy; 2003-2008 <a href='#'>www.My Template.com.</a> All Rights Reserved.");
	        out.println("<div class='desby'>Designed By: <a href='http://www.elegant-templates.com'>Elegant Web Templates</a></div>");
	      out.println("</div>");
	    out.println("</div>");
	  out.println("</center>");
	  out.println("</body>");
	  out.println("</html>");

	      	
    } catch (SQLException e) {
      throw new 
      ServletException("Servlet Could not display records.", e);
    } catch (ClassNotFoundException e) {
      throw new 
      ServletException("JDBC Driver not found.", e);
    } 
    finally {
      try {
        if(con != null) {
          con.close();
          con = null;
        }
      } catch (SQLException e) {}
    }

    out.print("</body></html>");
    out.close();
  }
}
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class login extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
             throws ServletException, IOException {

    res.setContentType("text/html");
    PrintWriter out = res.getWriter();
    
    HttpSession session = req.getSession(true);
    
    String uname = req.getParameter("username");
    String pass = req.getParameter("password");
    
    String temp = "login.html";
    
  
    Connection con = null;
        
    try {
	     Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
		//make a connection
		con=DriverManager.getConnection("jdbc:ucanaccess://C:/apache-tomcat/webapps/shop-online/WEB-INF/database/Ab sta.accdb");
		System.out.println("Connection Successful");
		//creating object of statement
		Statement stat=con.createStatement();
        ResultSet rs = stat.executeQuery("SELECT * FROM customer where username='" + uname + "' and password='" + pass + "'");
	  
      // displaying records
      while(rs.next()) {   	  
    	  session.setAttribute("userName", uname);
         temp ="index.html";  	
      	
      }
      
      res.sendRedirect(temp);  
      
      
    } catch (SQLException e) {
      throw new 
      ServletException("Servlet Could not display records.", e);
    } catch (ClassNotFoundException e) {
      throw new 
      ServletException("JDBC Driver not found.", e);
    } finally {
      try {
        if(con != null) {
          con.close();
          con = null;
        }
      } catch (SQLException e) {}
      out.close();
    }

}
}